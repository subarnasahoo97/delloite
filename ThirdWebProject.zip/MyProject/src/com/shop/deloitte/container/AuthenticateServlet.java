package com.shop.deloitte.container;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AuthenticateServlet
 */
@WebServlet("/AuthenticateServlet")
public class AuthenticateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AuthenticateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		PrintWriter out=response.getWriter();
		out.println("<h2>Welcome to authentication"+username);
		out.println("<h2>You are being authenticated");
		out.println();
		//if(username.startsWith("T")) {
			//RequestDispatcher dispatcher=request.getRequestDispatcher("Welcome");
			//dispatcher.include(request, response);
			
			//cookie
			Cookie allcookies[]=request.getCookies();
			boolean alreadyVisited=false;
			if(allcookies!=null) {
				for(Cookie c:allcookies) {
					if(c.getName().equals(username)) {
						alreadyVisited=true;
						break;
					}
				}
			}
			
			out.println("<h1>Successfully authenticated");
			if(!alreadyVisited) {
				out.println("<h1>Welcome,you are the first visitor,:"+username);
				Cookie cookie=new Cookie(username,username);
				response.addCookie(cookie);
				System.out.println("cookie set");
			}
			else {
				out.println("<h1>Welcome anyway,already visited.</h1>");
			}
			out.println("<h1><form action='Welcome'>");
			out.println("<h1>Wife name:<input type='text' name='wifename'>");
			out.println("<h1<input type='hidden' name='username' value="+username+">");
			out.println("<h1><input type='submit' value='Enter'>");
			out.println("<h1></form>");
		}
		/*else if(username.startsWith("S")) {
			RequestDispatcher dispatcher=request.getRequestDispatcher("Guest");
			dispatcher.forward(request, response);
		}
		else if(username.startsWith("P")) {
			RequestDispatcher dispatcher=request.getRequestDispatcher("Member");
			dispatcher.forward(request, response);
		}
		else {
			response.sendRedirect("loginForm.html");
		}*/
	}


