package com.shop.deloitte.container;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ConfirmProductServlet
 */
@WebServlet("/ConfirmProductServlet")
public class ConfirmProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ConfirmProductServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String selectedItems[]=request.getParameterValues("item");
		HttpSession session=request.getSession();
		String str=(String)session.getAttribute("currentBuyer");
		PrintWriter out=response.getWriter();
		if(selectedItems==null) {
			response.getWriter().println(str+"Dont be smart.Select atleast one.");
			response.getWriter().println("<a href='Item.html'>Go back</a>");
		}
		else {
			out.print("<h1>"+str+"You have selected the following products.</h1>");
			for(String products:selectedItems) {
				out.println("<h1>"+products+"</h1>");
			}
		}
	}

}
