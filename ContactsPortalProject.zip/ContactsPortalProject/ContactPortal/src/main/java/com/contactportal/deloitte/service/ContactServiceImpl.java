package com.contactportal.deloitte.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.contactportal.deloitte.dao.ContactsDAO;
import com.contactportal.deloitte.model.Contact;

@Service
public class ContactServiceImpl implements ContactService {

	@Autowired
	ContactsDAO contactDAO;
	
	
	@Override
	@Transactional
	public void addContact(Contact contact) {
		contactDAO.save(contact);
	}

	@Override
	public void deleteContact(int contactId) {
		contactDAO.deleteById(contactId);
	}

	@Override
	public void updateContact(Contact contact) {
		if(contactDAO.existsById(contact.getContactId()))
			contactDAO.save(contact);
	}

	@Override
	public Contact getContact(int contactId) {
		Optional<Contact> optionalContact=contactDAO.findById(contactId);
		Contact contact=new Contact();
		if(optionalContact.isPresent()) {
			contact=optionalContact.get();
		}
       return contact; 
	}

	@Override
	public boolean isContactExists(int contactId) {
		return contactDAO.existsById(contactId);
	}

	@Override
	public List<Contact> listContacts() {
		return (List<Contact>)contactDAO.findAll();
	}

	@Override
	public long countContacts() {
		System.out.println("#################################"+contactDAO.count());
		long count=contactDAO.count();
		return count;
	}
    
}