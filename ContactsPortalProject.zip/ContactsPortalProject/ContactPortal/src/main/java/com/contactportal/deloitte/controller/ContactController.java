package com.contactportal.deloitte.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.servlet.ModelAndView;

import com.contactportal.deloitte.model.Contact;

import com.contactportal.deloitte.service.ContactService;

@Controller

//@RequestMapping("contactPortal")

public class ContactController {

	@Autowired

	ContactService contactService;

	@RequestMapping("/saveContact")

	public ModelAndView saveContact(Contact contact) {

		ModelAndView view = new ModelAndView("redirect:/contact");

		view.addObject("contact", new Contact());

		contactService.addContact(contact);

//		System.out.println(contact);

		return view;

	}

	@RequestMapping("/editContact/{contId}")

	public ModelAndView editContact(@PathVariable("contId") Integer userId) {

//		System.out.println("####### Contact Portal Controller editContact");

		ModelAndView view = new ModelAndView("contactForm");

		Contact contact = contactService.getContact(userId);

		List<Contact> allContacts = contactService.listContacts();

		view.addObject("contact", contact);

		view.addObject("allContacts", allContacts);

		return view;

	}

	@RequestMapping(value = "/editContact/add/update")

	public String updateContact(Contact contact) {

		contactService.updateContact(contact);

		return "redirect:/contact";

	}

	@RequestMapping("/deleteContact/{contId}")

	public ModelAndView deleteContact(@PathVariable("contId") Integer userId) {

		ModelAndView view = new ModelAndView("redirect:/contact");

		contactService.deleteContact(userId);

		return view;

	}

	@RequestMapping("/viewContact")

	public ModelAndView viewContact() {

		ModelAndView view = new ModelAndView("contactView");

		return view;

	}

	@RequestMapping("/contact")

	public ModelAndView contactPortal() {

		ModelAndView view = new ModelAndView("contactForm");

		view.addObject("contact", new Contact());

		List<Contact> allContacts = contactService.listContacts();
		view.addObject("allContacts", allContacts);

		return view;
	}
}