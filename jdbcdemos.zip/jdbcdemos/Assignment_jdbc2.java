package jdbcdemos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Assignment_jdbc2 {
public static void main(String[] args) throws SQLException {
	 Product product=new Product();
	  product.deleteProduct();
	  Connection connection=DBConnection.makeConnection();
	  PreparedStatement statement=connection.prepareStatement("delete from hr.product where productId=?");
	  statement.setInt(1, product.getProductId());
	  
	  statement.executeUpdate();
}
}
