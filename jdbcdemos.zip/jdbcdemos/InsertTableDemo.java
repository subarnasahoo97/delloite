package jdbcdemos;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class InsertTableDemo {
public static void main(String[] args) throws SQLException {
	Connection conn=DBConnection.makeConnection();
	Statement stat=conn.createStatement();
	String insertQuery="insert into hr.customer values(1877,'Bibhu','Bhubaneswar',50000)";
	int rowsAffected=stat.executeUpdate(insertQuery);
	System.out.println("Inserted with"+rowsAffected+"rows");
}
}
