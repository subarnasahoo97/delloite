package jdbcdemos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Assignment_jdbc3 {
  public static void main(String[] args) throws SQLException {
	  Product product=new Product();
	  product.updateProduct();
	  
	  Connection connection=DBConnection.makeConnection();
	  PreparedStatement statement=connection.prepareStatement("update hr.product set productrName=?,price=?,qoh=? where productId=?");
	  statement.setInt(4, product.getProductId());
	  statement.setString(1, product.getProductName());
	  statement.setInt(2, product.getPrice());
	  statement.setInt(3, product.getQoh());
	  
	  
	  statement.executeUpdate();
	  System.out.println(product.getProductName()+", has been updated.");
  }
}

