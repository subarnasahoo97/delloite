package jdbcdemos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Assignment_jdbc {
public static void main(String[] args) throws SQLException {
	Connection conn=DBConnection.makeConnection();
	Statement stat=conn.createStatement();
	ResultSet res=stat.executeQuery("select * from hr.product");
	 while(res.next()) {
		  System.out.print(res.getInt(1)+" ");
		  System.out.print(res.getString(2)+" ");
		  System.out.print(res.getString(3)+" ");
		  System.out.println(res.getInt(4)+" ");
	  
	  }
	  stat.close();
	  conn.close();
	  
	 
	  
	  
	  		
}
}
