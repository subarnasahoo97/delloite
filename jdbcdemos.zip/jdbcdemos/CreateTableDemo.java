package jdbcdemos;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateTableDemo {
public static void main(String[] args) throws SQLException {
	Connection conn=DBConnection.makeConnection();
	System.out.println("Connected");
	
	Statement stat=conn.createStatement();
	String query="create table hr.salary(salary integer,bonus integer)";
	stat.execute(query);
	System.out.println("Done");
}
}
