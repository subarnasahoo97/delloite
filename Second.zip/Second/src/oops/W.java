package oops;

public class W {
   public W() {
	   System.out.println("W constructor");
   }
}
