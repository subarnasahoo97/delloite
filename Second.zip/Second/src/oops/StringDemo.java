package oops;

import java.util.Arrays;

public class StringDemo {
   public static void main(String[] args) {
	 String str="The quick brown fox jumps over the lazy dog.";
	 char c=str.charAt(12);	
	 System.out.println(c);
	 System.out.println(str.contains("is"));
     String str1=str.concat("and killed it");
     System.out.println(str1);
     System.out.println(str.equals(str1));
     String str2=str.toUpperCase();
     System.out.println(str.equals(str2));
     System.out.println(str.length());
     System.out.println(str.matches("The quick brown fox jumps over the lazy dog."));
     System.out.println(str.replaceAll("the", "A"));
     System.out.println(Arrays.toString(str.split("(?<=fox)")));
     String substr=str.substring(16,19);
     System.out.println(substr);
     String substr1=str.substring(40,43);
     System.out.println(substr1);
     System.out.println(str.toLowerCase());
     System.out.println(str.toUpperCase());
     for(int i=0;i<str.length();i++) {
    	 if(str.charAt(i)=='a') {
    		 System.out.println(i);
    	 }
     }
     System.out.println(str.lastIndexOf('e'));
    
   }
}
