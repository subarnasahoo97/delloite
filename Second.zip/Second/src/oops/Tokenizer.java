package oops;
import java.util.StringTokenizer;
public class Tokenizer {
         public static void main(String[] args) {
        	 String str="The quick brown fox jumps over the lazy dog.";
        	 StringTokenizer token=new StringTokenizer(str);
             System.out.println(token.countTokens());
             while(token.hasMoreTokens()) {
            	 System.out.println(token.nextElement());
             }
		}
}
