package oops;

public class Client {
	 public static void main(String[] args) {
			Customer c1=new Customer();
			c1.printDetails();
			Customer c2=new Customer(101,"Rohan","Pune",1000);
			c2.printDetails();
			Customer c3=new Customer(102,"Raj");
			c3.setCustomerAddress("Odisha");
			c3.setBillAmount(5000);
			c3.printDetails();
			
		}
}
