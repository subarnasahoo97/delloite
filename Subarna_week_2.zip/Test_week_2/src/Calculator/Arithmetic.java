package Calculator;

import java.util.Scanner;

public abstract class Arithmetic {
  int num1,num2;
  abstract int calc(int num1, int num2);
  
  public Arithmetic() {
	this.num1=num1;
	this.num2=num2;
  }
 
  public static int read() {
	  Scanner sc=new Scanner(System.in);
	  int num=sc.nextInt();
	  return num;
  }
  public static void display(int y) {
	  System.out.println("The result is:"+y);
  }
}
