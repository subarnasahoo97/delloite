package Calculator;

public class Multiply extends Arithmetic {
	@Override
	public int calc(int num1, int num2) {
		int num3= num1*num2;
		return num3;
	}
}
