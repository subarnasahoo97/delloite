package Calculator;

import java.util.Scanner;

public class Calculation {
public static void main(String[] args) {
	Object[] fs = {new Add(), new Subtract(), new Multiply(), new Divide()};
	System.out.println("Enter your choice:\n1. Add\n2. Sub\n3. Multiply\n4. Divide");
	int input;
	Scanner sc = new Scanner(System.in);
	input = sc.nextInt();
	int num1, num2;
	System.out.println("Enter two numbers: ");
	num1 = Arithmetic.read();
	num2 = Arithmetic.read();
	int y = ((Arithmetic)fs[input-1]).calc(num1, num2);
	Arithmetic.display(y);
	sc.close();
}
}
