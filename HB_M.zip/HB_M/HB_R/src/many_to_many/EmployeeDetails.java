package many_to_many;

import java.util.Set;

public class EmployeeDetails {
  private int employeeId;
  private String employeeName;
  private Set employeeAddress;
  private int employeeSalary;
  
  public EmployeeDetails() {
	// TODO Auto-generated constructor stub
    }
  public EmployeeDetails(int employeeId, String employeeName, int employeeSalary) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeSalary = employeeSalary;
	}



public int getEmployeeId() {
	return employeeId;
}

public void setEmployeeId(int employeeId) {
	this.employeeId = employeeId;
}

public String getEmployeeName() {
	return employeeName;
}

public void setEmployeeName(String employeeName) {
	this.employeeName = employeeName;
}

public Set getEmployeeAddress() {
	return employeeAddress;
}

public void setEmployeeAddress(Set employeeAddress) {
	this.employeeAddress = employeeAddress;
}

public int getEmployeeSalary() {
	return employeeSalary;
}

public void setEmployeeSalary(int employeeSalary) {
	this.employeeSalary = employeeSalary;
}

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + employeeId;
	result = prime * result + ((employeeName == null) ? 0 : employeeName.hashCode());
	result = prime * result + employeeSalary;
	return result;
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	EmployeeDetails other = (EmployeeDetails) obj;
	if (employeeId != other.employeeId)
		return false;
	if (employeeName == null) {
		if (other.employeeName != null)
			return false;
	} else if (!employeeName.equals(other.employeeName))
		return false;
	if (employeeSalary != other.employeeSalary)
		return false;
	return true;
}

@Override
public String toString() {
	return "EmployeeDetails [employeeId=" + employeeId + ", employeeName=" + employeeName + ", employeeSalary="
			+ employeeSalary + "]";
}

public EmployeeDetails(int employeeId, String employeeName, Set employeeAddress, int employeeSalary) {
	super();
	this.employeeId = employeeId;
	this.employeeName = employeeName;
	this.employeeAddress = employeeAddress;
	this.employeeSalary = employeeSalary;
}

}
