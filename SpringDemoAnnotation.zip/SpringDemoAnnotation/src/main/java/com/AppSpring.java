package com;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.config.AppConfig;

public class AppSpring 
{
    public static void main( String[] args )
    {   /*Resource resource=new ClassPathResource("beans.xml");*/
    	AbstractApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
       
        Customer customer=context.getBean(Customer.class);
        customer.setCustomerId(1990);
        customer.setCustomerName("Jaya");
        customer.setCustomerAddress("Pune");
        customer.setBillAmount(9800);
        
        
        ContactDetails contactDetails=context.getBean(ContactDetails.class);
        contactDetails.setMobileNo("9090876545");
        contactDetails.setEmailId("jaya@gmail.com");
        
        Customer customer1=context.getBean(Customer.class);
        System.out.println(customer);
        
        
        context.registerShutdownHook();
    }
}
