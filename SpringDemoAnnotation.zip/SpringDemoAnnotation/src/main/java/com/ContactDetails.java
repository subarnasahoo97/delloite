package com;

public class ContactDetails {
   private String mobileNo;
   private String emailId;
   
   public ContactDetails() {
	// TODO Auto-generated constructor stub
}

public ContactDetails(String mobileNo, String emailId) {
	super();
	this.mobileNo = mobileNo;
	this.emailId = emailId;
}

public String getMobileNo() {
	return mobileNo;
}

public void setMobileNo(String mobileNo) {
	this.mobileNo = mobileNo;
}

public String getEmailId() {
	return emailId;
}

public void setEmailId(String emailId) {
	this.emailId = emailId;
}

@Override
public String toString() {
	return "ContactDetails [mobileNo=" + mobileNo + ", emailId=" + emailId + "]";
}
}
