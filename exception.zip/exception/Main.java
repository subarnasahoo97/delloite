package exception;

public class Main {
  public static void main(String[] args) {
	  Product c=new Product(101,"TV",1,200000);
	  Product c1=new Product(102,"Laptop",1,100000);
	  Product c2=new Product(103,"Fridge",1,50000);
	  System.out.println(c);
	  System.out.println(c1);
	  System.out.println(c2);
  }
}
