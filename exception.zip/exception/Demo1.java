package exception;
import java.util.InputMismatchException;
import java.util.Scanner;
public class Demo1 {
 int num1,num2;
 int result;
 Scanner sc=new Scanner(System.in);
 public void display() {
	 System.out.println("Welcome in display");

 try {
	System.out.println("Enter 1st number"); 
	num1=sc.nextInt();
	System.out.println("Enter 2nd number"); 
	num2=sc.nextInt();
	result=num1/num2;
	System.out.println(result);
 }
 catch(InputMismatchException e){
	 System.out.println("Enter a no.");
 }
 catch(ArithmeticException e){
	 System.out.println("dont enter 0");
 }
}
 public static void main(String[] args) {
	Demo1 d=new Demo1();
	d.display();
}
}
