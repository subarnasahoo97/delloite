package exception;
import java.util.Scanner;
class InvalidAgeException extends Exception{
	public InvalidAgeException() {
		
	}
	public InvalidAgeException(String msg) {
		super(msg);
	}
}

class NewYearParty{
	int eligibleAge=16;
	Scanner sc=new Scanner(System.in);
	int age;
	public void enterClub() throws InvalidAgeException{
		System.out.println("Please enter age");
		age=sc.nextInt();
		if(age<eligibleAge) {
			throw new InvalidAgeException("Under age");
		}
		else {
			System.out.println("Come");
		}
		System.out.println("Enjoy");
	}
}
public class Demo3 {
   public static void main(String[] args) throws InvalidAgeException {
	System.out.println("Welcome");
	NewYearParty d=new NewYearParty();
	d.enterClub();
	System.out.println("end");
	
}
}
