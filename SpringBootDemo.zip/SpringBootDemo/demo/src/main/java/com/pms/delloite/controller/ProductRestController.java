package com.pms.delloite.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pms.delloite.model.Product;
import com.pms.delloite.service.ProductService;


@RestController
@RequestMapping("product")
public class ProductRestController {

	
	@Autowired
    ProductService productService;
	
	@RequestMapping("getProduct")
	public List<Product> product() {
		List<Product> allListProducts= productService.listProducts();
		return allListProducts;
	}
}
