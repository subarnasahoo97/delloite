package com.pms.delloite.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.pms.delloite.dao.ProductDAO;
import com.pms.delloite.model.Product;
import com.pms.delloite.service.ProductService;

@Controller
public class ProductController {
    
	@Autowired
	ProductService productService;
	
	@RequestMapping("product")
	public ModelAndView ProductForm() {
		ModelAndView view = new ModelAndView("productForm");
		view.addObject("product",new Product());
		List<Product> allProducts= productService.listProducts();
		view.addObject("allProducts",allProducts);
		return view;
	}
	
	
	@RequestMapping("saveProduct")
	public ModelAndView saveProduct(Product product) {
		ModelAndView view=new ModelAndView("redirect:/product");
		view.addObject("product", new Product());
		List<Product> allProducts= productService.listProducts();
		view.addObject("allProducts",allProducts);
		productService.addProduct(product);
		System.out.println(product);
		return view;
	}
	
	@RequestMapping("deleteProduct/{prodId}")
	public ModelAndView deleteProduct(@PathVariable("prodId")Integer productId) {
		System.out.println("Delete prod called"+productId);
		productService.deleteProduct(productId);
		ModelAndView view=new ModelAndView("redirect:/product");
		view.addObject("product",new Product());
		return view;
	}
	
	@RequestMapping("editProduct/{prodId}")
	public ModelAndView editProduct(@PathVariable("prodId")Integer productId) {
		System.out.println("Edit prod called"+productId);
		Product product=productService.getProduct(productId);
		ModelAndView view=new ModelAndView("productForm");
		List<Product> allProducts= productService.listProducts();
		view.addObject("allProducts",allProducts);
		view.addObject("product",product);
		return view;
	}
	
	@RequestMapping("/editProduct/add/update")
	public String updatePerson(Product product) {
		System.out.println("update prod called"+product);
		this.productService.updateProduct(product);
		return "redirect:/product";
	}
	
	  
}
