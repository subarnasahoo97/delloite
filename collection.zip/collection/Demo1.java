package collection;
import java.util.ArrayList;
import java.util.List;
public class Demo1 {
   public static void main(String[] args) {
	List names=new ArrayList();
	names.add("Sumeeet");
	names.add("Zeeshan");
	names.add("Abhishek");
	names.add("Abhishek");
	System.out.println(names);
	
	
	
	names.add(2,"Reddy");
	System.out.println(names);
	
	
	
	names.remove("Abhishek");
	System.out.println(names);
	
	System.out.println(names.isEmpty());
}
}
