package collection;
import java.util.Set;
import java.util.LinkedHashSet;
public class Demo2 {
   public static void main(String[] args) {
	Set names=new LinkedHashSet();
	names.add("Abcd");
	names.add("Pqrs");
	names.add("Wxyz");
	System.out.println(names);
}
}
