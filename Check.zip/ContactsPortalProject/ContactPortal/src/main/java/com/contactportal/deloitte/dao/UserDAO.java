package com.contactportal.deloitte.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.contactportal.deloitte.model.Contact;
import com.contactportal.deloitte.model.User;

@Repository
public interface UserDAO extends CrudRepository<User, Integer> {

	public boolean findByUserIdAndPassword(int userId,String password);
	
}