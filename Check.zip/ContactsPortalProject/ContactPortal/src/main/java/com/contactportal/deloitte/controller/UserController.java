package com.contactportal.deloitte.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.servlet.ModelAndView;

import com.contactportal.deloitte.model.Contact;
import com.contactportal.deloitte.model.User;
import com.contactportal.deloitte.service.ContactService;
import com.contactportal.deloitte.service.UserService;

@Controller

//@RequestMapping("contactPortal")

public class UserController {

	@Autowired

	UserService userService;

	@RequestMapping("/signUp")

	public ModelAndView saveUser(User user) {

		ModelAndView view = new ModelAndView("redirect:/login");

		view.addObject("user",new User());

		userService.addUser(user);


		return view;
	}
}