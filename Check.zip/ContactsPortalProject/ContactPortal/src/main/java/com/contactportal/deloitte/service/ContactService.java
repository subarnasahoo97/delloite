package com.contactportal.deloitte.service;

import java.util.List;

import com.contactportal.deloitte.model.Contact;

public interface ContactService {

	public void addContact(Contact contact);
	public void deleteContact(int contactId);
	public void updateContact(Contact contact);
	public Contact getContact(int contactId);
	public boolean isContactExists(int contactId);
	public List<Contact> listContacts();
	public long countContacts();
}
