package com.todo.service;

import com.todo.model.Login;

public interface LoginService {
	public void addUser(Login login);
	public boolean validateuser(Login login);

}
