package com.todo.service;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.todo.model.ToDo;


public interface ToDoService {
	
	public void addToDo(ToDo toDo);
	
	public void deleteToDo(int id);
	
	public void updateToDo(ToDo toDo);
	
	public List<ToDo> ListToDo();
	
	public List<ToDo> sortByDateToDo(String username);
	
	public ToDo getTodo(int id);
	
	public List<ToDo> listByUsername(String username);
	
	public List<ToDo> listAllTodo();

}
