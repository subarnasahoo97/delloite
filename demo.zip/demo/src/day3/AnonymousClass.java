package day3;

public class AnonymousClass {
public static void main(String[] args) {
	ChangePassword1 c=new ChangePassword1()
	{
	@Override
	public void doChange() {
		System.out.println("password changed successfully");
	}
	};
	c.doChange();
}
}
interface ChangePassword1{
	void doChange();
}
