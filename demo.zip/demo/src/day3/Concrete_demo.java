package day3;

abstract class Animals {
	public abstract void makeNoise();
	public abstract void roam();
	public abstract void eat();
	public void sleep() {
		System.out.println("Animal sleeps");
	}
}
 abstract class Feline extends Animals{
	@Override
	public void roam() {
		System.out.println("Feline roams");
	}
	
}
 class Hippo extends Animals{
	@Override
	public void roam() {
		System.out.println("Hippo roams");
	}
	@Override
	public void makeNoise() {
		System.out.println("Hippo makes noise");
	}
	@Override
	public void eat() {
		System.out.println("Hippo eats");
	}
}
 abstract class Canine extends Animals{
	@Override
	public void roam() {
		System.out.println("Canine roams");
	}
}
 class Lion extends Feline{
	@Override
	public void makeNoise() {
		System.out.println("Lion roars");
	}
	@Override
	public void eat() {
		System.out.println("Lion eats meat");
	}
}
 class Tiger extends Feline{
	@Override
	public void makeNoise() {
		System.out.println("Tiger roars");
	}
	@Override
	public void eat() {
		System.out.println("Tiger eats meat");
	}
}
 class Cats extends Feline{
	@Override
	public void makeNoise() {
		System.out.println("Cat meows");
	}
	@Override
	public void eat() {
		System.out.println("Cat eats meat");
	}
}
 class Dogs extends Canine{
	@Override
	public void makeNoise() {
		System.out.println("Dog barks");
	}
	@Override
	public void eat() {
		System.out.println("Dog eats meat");
	}
}
 class Wolf extends Canine{
	@Override
	public void makeNoise() {
		System.out.println("Wolf makes noise");
	}
	@Override
	public void eat() {
		System.out.println("Wolf eats meat");
	}
}
public class Concrete_demo {
 public static void main(String[] args) {
	
	Feline d=new Lion();
	d.roam();
	d.makeNoise();
	d.eat();
	
	Feline e=new Tiger();
	e.roam();
	e.makeNoise();
	e.eat();
	
	Feline f=new Cats();
	f.roam();
	f.makeNoise();
	f.eat();
	
	Hippo b=new Hippo();
	b.roam();
	b.makeNoise();
	b.eat();
	
	Canine g=new Dogs();
	g.roam();
	g.makeNoise();
	g.eat();
	
	Canine h=new Wolf();
	h.roam();
	h.makeNoise();
	h.eat();
	
	
}
}
