package day3;

class ChangePassword {
	String password = "pass@123";

	class EncryptPassword {
		public void doencrypt() {
			System.out.println("The password is:" + password);
		}
	}
}

public class InnerClass {
	public static void main(String[] args) {
		ChangePassword pa = new ChangePassword();
		ChangePassword.EncryptPassword e = pa.new EncryptPassword();
		e.doencrypt();

	}
}
