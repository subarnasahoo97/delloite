package day3;


class ChangePasswords {
	static String password = "pass@123";

	static class EncryptPasswords {
		public void doencrypt() {
			System.out.println("The password is:" + password);
		}
	}
}

public class StaticInnerClass {
	public static void main(String[] args) {
		ChangePasswords pa = new ChangePasswords();
		ChangePasswords.EncryptPasswords e = new ChangePasswords.EncryptPasswords();
		e.doencrypt();

	}
}