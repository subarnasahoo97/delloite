package day3;

public class Final_demo {

	final int UPPER_AGE;
	Final_demo(){
		UPPER_AGE=10;
		System.out.println(UPPER_AGE);
	}
	Final_demo(int i){
		//this();
		UPPER_AGE=20;
		System.out.println(UPPER_AGE);
	}
	public static void main(String[] args) {
		Final_demo d=new Final_demo(8);
		Final_demo d1=new Final_demo();
		
	}
}
