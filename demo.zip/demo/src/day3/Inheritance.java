package day3;

abstract class Animal {
     public abstract void eat();
     public void sleep() {
    	 System.out.println("Animal sleeps");
     }
}
	
class Dog extends Animal{
	@Override
	public void eat() {
		System.out.println("Dog eats meat");
	}
	public void bark() {
		System.out.println("Dog barks");
	}
}
class Cat extends Animal{
	@Override
	public void eat() {
		System.out.println("Cat eats milk");
	}
}
	
public class Inheritance{
	public static void main(String[] args) {
		Animal a=new Dog();
		a.eat();
		a=new Cat();
		a.eat();
	}
}