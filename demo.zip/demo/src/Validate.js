
function display(){
 var num1=prompt("Enter first number","12");
 var num2=prompt("Enter first number","12");
 var result=parseInt(num1)+parseInt(num2);
 alert("The sum of two numbers are:"+result);
 }
 function demo(){
	 var res=confirm("Do you want to continue:");
	 if (res==true){
		alert("Ok clicked") 
	 }
	 else{
		 alert("Cancel clicked");
	 }
 }
 