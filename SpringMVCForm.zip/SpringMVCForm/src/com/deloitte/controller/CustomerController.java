package com.deloitte.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cms.delloite.dao.CustomerDAO;
import com.cms.delloite.dao.impl.CustomerDAOImpl;
import com.cms.delloite.model.Customer;
import com.cms.delloite.service.CustomerService;
@Controller
public class CustomerController {
      
	  @Autowired
	  CustomerService customerService;
	  @RequestMapping("customerSave")
	  public ModelAndView saveCustomerDetails(Customer customer) {
		  
		  System.out.println(customer);
		  customerService.addCustomer(customer);
		  ModelAndView view=new ModelAndView();
		  view.setViewName("result");
		  view.addObject("custo",customer);
		  return view;
}
	  
	  
	  @RequestMapping("updateCustomer")
	  public ModelAndView updateCustomerDetails(Customer customer) {
		  
		  System.out.println(customer);
		  ModelAndView view=new ModelAndView();
		  view.addObject("custo", customer);
		  if(customerService.isCustomerExists(customer.getCustomerId())) {
			  customerService.updateCustomer(customer);
			  view.setViewName("result");
		  }
		  
		  
		  else {
			  view.setViewName("error");
		  }
		  
		  
		  return view;
}
	  
	  
	  @RequestMapping("customerDetails")
	  public ModelAndView customerDetails(HttpSession session) {
		 
		  ModelAndView view=new ModelAndView();
		  view.setViewName("allCustomerRecords");
		  List<Customer> allCustomers=customerService.listCustomer();
		  session.setAttribute("allCust",allCustomers);
		  return view;
}
	  
	  
	  @RequestMapping("customerForm")
	  public ModelAndView customerForm() {
		
		  ModelAndView view=new ModelAndView();
		  view.setViewName("customerForm");
		  view.addObject("command",new Customer());
		  return view;
}
	  
	  
	  @RequestMapping("fetchCustomer")
	  public ModelAndView fetchCustomer(Customer customer) {
		  ModelAndView view=new ModelAndView();
		  Customer retrievedCustomer=customerService.findCustomer(customer.getCustomerId());
		  view.addObject("command",retrievedCustomer);
		  view.setViewName("customerForm");
		 
		  return view;
}

}
