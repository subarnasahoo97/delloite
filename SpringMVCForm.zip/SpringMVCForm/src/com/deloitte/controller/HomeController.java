package com.deloitte.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {
  @RequestMapping("/ahmed")
  public String gg() {
	  return "ghosia";
  }
  
  
  @RequestMapping("/customer")
  public String pp() {
	  return "cust";
  }
  
  @RequestMapping("/Employee")
  public String oo() {
	  return "Employee";
  }
  
  @RequestMapping("/Product")
  public String ss() {
	  return "Product";
  }
}
