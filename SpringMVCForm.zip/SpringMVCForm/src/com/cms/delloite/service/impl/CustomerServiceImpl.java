package com.cms.delloite.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cms.delloite.dao.CustomerDAO;
import com.cms.delloite.model.Customer;
import com.cms.delloite.service.CustomerService;

public class CustomerServiceImpl implements CustomerService {
	
	
    @Autowired
    CustomerDAO customerDAO;
    
    
	@Override
	public boolean addCustomer(Customer customer) {
		boolean result=true;
		if(customer.getBillAmount()>0) {
	      customerDAO.addCustomer(customer);
	      }
		else {
			result=false;
		}
		return result;
	}

	@Override
	public boolean updateCustomer(Customer customer) {
		return customerDAO.updateCustomer(customer);
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		return customerDAO.deleteCustomer(customerId);
	}

	@Override
	public List<Customer> listCustomer() {
		return customerDAO.listCustomer();
	}

	@Override
	public Customer findCustomer(int customerId) {
		return customerDAO.findCustomer(customerId);
	}

	@Override
	public boolean isCustomerExists(int customerId) {
		return customerDAO.isCustomerExists(customerId);
	}

}
