package com;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Welcome extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public Welcome() {
        super();
        System.out.println("Welcome cons called.");
    }
    
    public void display() {
    	System.out.println("Display called.");
    }
    
    
    public void init() {
    	System.out.println("INIT called.");
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	System.out.println("doget called.");
		counter++;
		
		
		String usern=request.getParameter("username");
		String pass=request.getParameter("password");
		response.getWriter().println("<body bgcolor='blue'><h1>Welcome to my website-"+usern+"</h1>");
		response.getWriter().println("<h1>Your Password-"+pass+"</h1>");
		response.getWriter().println("<h1>you are Visitor no :"+ counter);
		response.getWriter().println("<h1><a href='Shop.html'>Shop</a></h1>");
    }
    
    
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	System.out.println("doPost called.");
		counter++;
		
		
		String usern=request.getParameter("username");
		String pass=request.getParameter("password");
		response.getWriter().println("<body bgcolor='green'><h1>Welcome to my website-"+usern+"</h1>");
		response.getWriter().println("<h1>Your Password-"+pass+"</h1>");
		response.getWriter().println("<h1>you are Visitor no :"+ counter);
		response.getWriter().println("<h1><a href='Shop.html'>Shop</a></h1>");
    }
    @Override
    public void destroy() {
    	System.out.println("Destroy called");
    }

	int counter=0;
	protected void service(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		System.out.println("Service called.");
		counter++;
		
		
		String usern=request.getParameter("username");
		String pass=request.getParameter("password");
		response.getWriter().println("<body bgcolor='red'><h1>Welcome to my website-"+usern+"</h1>");
		response.getWriter().println("<h1>Your Password-"+pass+"</h1>");
		response.getWriter().println("<h1>you are Visitor no :"+ counter);
		response.getWriter().println("<h1><a href='Shop.html'>Shop</a></h1>");
	}

}
