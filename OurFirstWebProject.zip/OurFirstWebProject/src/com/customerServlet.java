package com;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cms.delloite.dao.CustomerDAO;
import com.cms.delloite.dao.impl.CustomerDAOImpl;
import com.cms.delloite.model.Customer;

/**
 * Servlet implementation class customerServlet
 */
public class customerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public customerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    protected void service(HttpServletRequest request, HttpServletResponse response)
    		throws ServletException, IOException {
    		
    		int customerid=Integer.parseInt(request.getParameter("customerid"));
    		String customername=request.getParameter("customername");
    		String customeraddress=request.getParameter("customeraddress");
    		int billamount=Integer.parseInt(request.getParameter("billamount"));
    		
    		Customer customer=new Customer(customerid,customername,customeraddress,billamount);
    		CustomerDAO customerDAO=new CustomerDAOImpl();
    		if(customerDAO.isCustomerExists(customerid)) {
    			response.getWriter().println(customerid+"already exists");
    		}
    		else {
    			customerDAO.addCustomer(customer);
    			response.getWriter().println(customerid+"added successfully");
    		}
    		
    	}

}
