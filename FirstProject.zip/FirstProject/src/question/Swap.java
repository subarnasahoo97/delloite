package question;
public class Swap {
  public void swap(int a,int b) {
	  int c=a+b;
	  a=(c)-a;
	  b=(c)-b;
	  System.out.println("a="+a+" b="+b);
	 
  }
 
}
