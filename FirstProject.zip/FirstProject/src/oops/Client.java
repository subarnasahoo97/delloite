package oops;

public class Client {
public static void main(String[] args) {
	Employee employee=new Employee();
	employee.takeSalary();
	employee.printDetails();
}
}
