package oops;

import java.util.Scanner;

public class Employee {
 public int employeeId;
 public String employeeName;
 public String employeeAddress;
 public int salary;
 
 public void takeSalary() {
	 Scanner sc=new Scanner(System.in);
	 System.out.println("Please enter employeeId");
	 employeeId=sc.nextInt();
	 sc.nextLine();
	 System.out.println("Please enter employeeName");
	  employeeName=sc.nextLine();	
	 System.out.println("Please enter employeeAddress");
	 employeeAddress=sc.nextLine();
	 System.out.println("Please enter salary");
	  salary=sc.nextInt();
		
	 
 }
 public void printDetails() {
	 System.out.println(employeeId);
	 System.out.println(employeeName);
	 System.out.println(employeeAddress);
	 System.out.println(salary);
 }
}
