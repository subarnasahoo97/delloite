
public class Cat {
	public void sayThanksCat() {
		System.out.println("In cat class");
	}
}
