package finance;

public class Salary {
       public int calculateSalary(int salary,int pf) {
    	   return salary+pf;
       }
}
