
public class Ball {
	public void sayThanksBall() {
		System.out.println("In ball class");
	}
}
