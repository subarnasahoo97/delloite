
public class Apple {
	public void sayApple() {
		System.out.println("In apple class");
	}
}
