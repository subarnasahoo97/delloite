import finance.Salary;
public class Welcome {

	public static void main(String[] args) {
		System.out.println("Welcome in Eclipse");
        Bye b=new Bye();
        b.sayThanks();
        Apple a=new Apple();
        a.sayApple();
        Ball c=new Ball();
        c.sayThanksBall();
        Cat d=new Cat();
        d.sayThanksCat();
        Salary salary=new Salary();
        int result=salary.calculateSalary(65000,3500);
        System.out.println(result);
	}

}
