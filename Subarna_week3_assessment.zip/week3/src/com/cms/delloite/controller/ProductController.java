package com.cms.delloite.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cms.delloite.dao.ProductDAO;
import com.cms.delloite.dao.impl.ProductDAOImpl;
import com.cms.delloite.model.Product;

/**
 * Servlet implementation class ProductController
 */
public class ProductController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int productId=Integer.parseInt(request.getParameter("productId"));
		String productName=request.getParameter("productName");
		int qoh=Integer.parseInt(request.getParameter("qoh"));
		int price=Integer.parseInt(request.getParameter("price"));
		
		Product product=new Product(productId,productName,qoh,price);
		ProductDAO productDAO=new ProductDAOImpl();
		productDAO.addProduct(product);
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		out.println(product.getProductName()+" added successfully!!");
		out.println("<html><head><title>View</title></head><body><div align='center'>");
		out.println("<form action='Welcome.jsp'><input type='submit' value='View Products'></form>");
		out.println("</div></body></html>");
		
		
	}

}
