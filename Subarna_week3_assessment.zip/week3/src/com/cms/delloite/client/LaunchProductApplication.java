package com.cms.delloite.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cms.delloite.dao.ProductDAO;
import com.cms.delloite.dao.impl.ProductDAOImpl;
import com.cms.delloite.model.Product;

public class LaunchProductApplication {
	public static void startProductApp() {
		while(true) {
		ProductDAO productDAO=new ProductDAOImpl();
		System.out.println("#### Welcome to Hibernate Customer App ####");
		System.out.println("#### 1.Add Product ####");
		System.out.println("#### 2.Update Product ####");
		System.out.println("#### 3.Delete Product ####");
		System.out.println("#### 4.Fetch Single Product ####");
		System.out.println("#### 5.Fetch All Product ####");
		System.out.println("#### 6.EXIT ####");
		
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your choice(1-6)");
		int choice=sc.nextInt();
		
		if(choice==1) {
			Product product=new Product();
			product.acceptProductDetails();
			boolean result=false;
			if(productDAO.isProductExists(product.getProductId())) {
				System.out.println(product.getProductId()+"does not exists.");
			}
			else {
			result=productDAO.addProduct(product);
			System.out.println(product.getProductName()+"added.");
			}
			
		}
		if(choice==2) {
			System.out.println("Please enter the new details:");
			Product product=new Product();
			product.acceptProductDetails();
			if(productDAO.isProductExists(product.getProductId())) {
				productDAO.updateProduct(product);
				System.out.println(product.getProductName()+"updated successfully.");
			}
			else {
				System.out.println(product.getProductId()+"does not exists.");
			}
			
		}
		if(choice==3) {
			System.out.println("Please enter productId to delete.");
			int productId=sc.nextInt();
			if(productDAO.isProductExists(productId)) {
				productDAO.deleteProduct(productId);
				System.out.println(productId+"deleted successfully.");
			}
			else {
				System.out.println(productId+"does not exists.");
			}
		}
		if(choice==4) {
			System.out.println("Please enter productId to search.");
			int productId=sc.nextInt();
			if(productDAO.isProductExists(productId)) {
				Product product=productDAO.findProduct(productId);
				System.out.println(product);
			}
			else {
				System.out.println(productId+"does not exists.");
			}
		}
		if(choice==5) {
			List<Product> allProducts=new ArrayList<Product>();
			allProducts=productDAO.listProduct();
			System.out.println("List of all products.");
			System.out.println(allProducts);
		}
		if(choice==6) {
			System.out.println("Thanks for using my product app");
			System.exit(0);
		}
	}
	}
}
