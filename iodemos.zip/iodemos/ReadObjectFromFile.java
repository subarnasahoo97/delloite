package iodemos;
import java.io.*;
public class ReadObjectFromFile {
	 public static void main(String [] args) throws FileNotFoundException, IOException, ClassNotFoundException {
		  Customer c=new Customer();
	
		  ObjectInputStream stream=new ObjectInputStream
				  (new BufferedInputStream(new FileInputStream(new File("delu.txt"))));
		 c=(Customer)stream.readObject();
		  System.out.println(c);
	  }
}
