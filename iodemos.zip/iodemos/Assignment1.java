package iodemos;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
public class Assignment1 {
public static void main(String[] args) throws IOException {
	File file=new File("record.txt");
	FileReader fr=new FileReader(file);
	FileWriter fw=new FileWriter("writable.txt");
	int i=0;
	while((i=fr.read())!=-1) {
		fw.write((char)i);
	}
	fw.close();
	fr.close();
}
}
