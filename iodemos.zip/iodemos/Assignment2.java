package iodemos;

	import java.io.File;
	import java.io.FileNotFoundException;
	import java.io.FileReader;
	import java.io.FileWriter;
	import java.io.IOException;
	import java.util.*;
	public class Assignment2 {
	public static void main(String[] args) throws IOException {
		String readfile,writefile;
		System.out.println("enter the file to copy");
		
		Scanner sc=new Scanner(System.in);
	    readfile=sc.next();
	    File read=new File(readfile);
		FileReader fr=new FileReader(readfile);
		if(read.exists()==false) {
			System.out.println("exit");
		}
		else {
	
		System.out.println("enter the file to paste");
		Scanner sc1=new Scanner(System.in);
	    writefile=sc1.next();
		FileWriter fw=new FileWriter(writefile);
		int i=0;
		while((i=fr.read())!=-1) {
			fw.write((char)i);
		}
		fw.close();
		fr.close();
	}
	}
	}


