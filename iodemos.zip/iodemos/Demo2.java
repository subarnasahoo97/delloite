package iodemos;
import java.io.*;
public class Demo2 {
public static void main(String[] args) throws IOException {
	File file=new File("mohan.txt");
	FileReader reader=new FileReader(file);
	int i=0;
	while((i=reader.read())!=-1) {
		System.out.print((char)i);
	}
	reader.close();
}
}
