package iodemos;
import java.io.*;
public class Main {
  public static void main(String [] args) throws FileNotFoundException, IOException {
	  Customer c=new Customer();
	  c.accept();
	  
	  ObjectOutputStream stream=new ObjectOutputStream
			  (new BufferedOutputStream(new FileOutputStream(new File("delu.txt"))));
	  stream.writeObject(c);
	  stream.close();
	  System.out.println("Data stored");
  }
}
