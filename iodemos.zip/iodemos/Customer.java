package iodemos;
import java.io.Serializable;
import java.util.*;
public class Customer implements Comparable<Customer>,Serializable{
	 private int customerid;
     private String customername;
     private String customeraddress;
     private transient int billAmount;
     
     
     public void accept() {
         Scanner scanner = new Scanner(System.in);
         System.out.println("Enter customer id : "); customerid = scanner.nextInt();
         System.out.println("Enter customer name : "); customername = scanner.next();
         System.out.println("Enter customer address : "); customeraddress = scanner.next();
         System.out.println("Enter bill amount : "); billAmount = scanner.nextInt();
     }
     
     public Customer() {
    	 
     }

	public Customer(int customerid, String customername, String customeraddress, int billAmount) {
		super();
		this.customerid = customerid;
		this.customername = customername;
		this.customeraddress = customeraddress;
		this.billAmount = billAmount;
	}

	public int getCustomerid() {
		return customerid;
	}

	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}

	public String getCustomername() {
		return customername;
	}

	public void setCustomername(String customername) {
		this.customername = customername;
	}

	public String getCustomeraddress() {
		return customeraddress;
	}

	public void setCustomeraddress(String customeraddress) {
		this.customeraddress = customeraddress;
	}

	public int getBillAmount() {
		return billAmount;
	}

	public void setBillAmount(int billAmount) {
		this.billAmount = billAmount;
	}

	@Override
	public String toString() {
		return "Customer [customerid=" + customerid + ", customername=" + customername + ", customeraddress="
				+ customeraddress + ", billAmount=" + billAmount + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + billAmount;
		result = prime * result + ((customeraddress == null) ? 0 : customeraddress.hashCode());
		result = prime * result + customerid;
		result = prime * result + ((customername == null) ? 0 : customername.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (billAmount != other.billAmount)
			return false;
		if (customeraddress == null) {
			if (other.customeraddress != null)
				return false;
		} else if (!customeraddress.equals(other.customeraddress))
			return false;
		if (customerid != other.customerid)
			return false;
		if (customername == null) {
			if (other.customername != null)
				return false;
		} else if (!customername.equals(other.customername))
			return false;
		return true;
	}

	@Override
	public int compareTo(Customer o) {
		if(this.getBillAmount()>o.getBillAmount()) {
			return 0;
		}
		else
		{
			return -1;
		}
	}
     
     
}
