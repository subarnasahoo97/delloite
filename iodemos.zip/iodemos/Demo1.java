package iodemos;
import java.io.*;

public class Demo1 {
  public static void main(String[] args) throws IOException {
	 File file=new File("c:\\delloite\\K\\T\\newyear.txt");
	 
	 File h=new File("c:\\delloite\\K\\T");
	 
	 if(file.exists()) {
		 System.out.println("File there");
		 file.delete();
	 }
	 else {
		 h.mkdirs();
		 file.createNewFile();
		 System.out.println("New file created");
	 }
	 
	 
	System.out.println("Done"); 
	 
}
}
