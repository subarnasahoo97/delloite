package iodemos;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Demo4 {
	public static void main(String[] args) throws IOException {
		
		FileWriter fw=new FileWriter("record.txt");
		fw.write("My name is Subarna Sahoo");
		fw.close();
		System.out.println("done");
	}
}
