package com;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.config.AppConfig;

public class Client {
public static void main(String[] args) {
	ApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
    
    Email email=context.getBean(Email.class);
    
    
    To to=context.getBean(To.class);
    to.setToName("Jaya");
    to.setToEmail("jaya@gmail.com");
    
    
    From from=context.getBean(From.class);
    from.setFromName("Subarna");
    from.setFromEmail("subarna3@gmail.com");
    
    
    Subject subject=context.getBean(Subject.class);
    subject.setCaption("Update about reservation.");
    
    
    Body body=context.getBean(Body.class);
    body.setMessage("Your appointment has been reserved.");
   
    System.out.println(email);
}
}
