package com.cms.deloitte.model;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

public class CustomTag extends TagSupport {
  @Override
public int doStartTag() throws JspException{
	  JspWriter out=pageContext.getOut();
	  
	  try {
		  for (int i = 0; i < 5; i++) {
				out.println("Subarna<br/>");
			}
	       } 
	  catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return super.doStartTag();  
  }
}
