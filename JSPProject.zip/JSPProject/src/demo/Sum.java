package demo;

public class Sum {
 public int addNumbers(int i,int j) {
	 return i+j;
 }
}
